/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=4x8 bulletBitmap Solid_white.png
 * Time-stamp: Monday 04/07/2025, 00:18:02
 *
 * Image Information
 * -----------------
 * Solid_white.png 4@8
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "bulletBitmap.h"

const unsigned short bulletBitmap[32] = {
    0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff,
    0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff, 0x7fff
};
