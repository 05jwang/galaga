/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=4x8 bulletBitmap Solid_white.png
 * Time-stamp: Monday 04/07/2025, 00:18:02
 *
 * Image Information
 * -----------------
 * Solid_white.png 4@8
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BULLETBITMAP_H
#define BULLETBITMAP_H

extern const unsigned short bulletBitmap[32];
#define BULLETBITMAP_SIZE 64
#define BULLETBITMAP_LENGTH 32
#define BULLETBITMAP_WIDTH 4
#define BULLETBITMAP_HEIGHT 8

#endif
