/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 alienBitmap alien.png
 * Time-stamp: Monday 04/07/2025, 00:19:07
 *
 * Image Information
 * -----------------
 * alien.png 16@16
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ALIENBITMAP_H
#define ALIENBITMAP_H

extern const unsigned short alienBitmap[256];
#define ALIEN_SIZE 512
#define ALIEN_LENGTH 256
#define ALIEN_WIDTH 16
#define ALIEN_HEIGHT 16

#endif
