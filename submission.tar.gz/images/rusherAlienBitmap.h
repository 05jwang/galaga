/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 rusherAlienBitmap rusher_alien.jpg
 * Time-stamp: Monday 04/07/2025, 00:19:40
 *
 * Image Information
 * -----------------
 * rusher_alien.jpg 16@16
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RUSHERALIENBITMAP_H
#define RUSHERALIENBITMAP_H

extern const unsigned short rusherAlienBitmap[256];
#define RUSHER_ALIEN_SIZE 512
#define RUSHER_ALIEN_LENGTH 256
#define RUSHER_ALIEN_WIDTH 16
#define RUSHER_ALIEN_HEIGHT 16

#endif
